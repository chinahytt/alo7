package appium.tutorial.ios;

import appium.tutorial.ios.page.LoginPage;
import appium.tutorial.ios.page.TutorialPage;
import appium.tutorial.ios.util.AppiumTest;

import java.io.IOException;

import static appium.tutorial.ios.util.Helpers.back;

public class LoginTest extends AppiumTest {

    @org.junit.Test
    public void pageObject() throws Exception {
        TutorialPage tutorialPage = new TutorialPage(driver);
        tutorialPage.loginButtonTapped();

        LoginPage loginPage = new LoginPage(driver);
        loginPage.waitAWhile();
        System.out.println("Enter login page");

        loginPage.toggleButtonTapped();
        System.out.println("Toggle button tapped");

        loginPage.waitForToggleChanged();
        System.out.println("Title changed");

        loginPage.findTextfields();
        loginPage.enterUsername("13524276478");
        loginPage.enterPassword("222222");

        loginPage.loginTapped();
    }
}
