package appium.tutorial.ios.util;

public class ConfigUtils {
    public static final String IOS_PLATFORM = "iOS";
    public static final String ANDROID_PLATFORM = "Android";

    private static final class Holder {
        public static final ConfigUtils INSTANCE = new ConfigUtils();
    }

    public static ConfigUtils getInstance() {
        return Holder.INSTANCE;
    }


    public boolean isIOSPlatform() {
        return false;
    }
}
